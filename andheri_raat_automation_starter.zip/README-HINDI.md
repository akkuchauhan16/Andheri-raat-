# Andheri Raat — Hindi Horror Shorts Automation

Yeh GitHub Actions starter project roz 2 Hindi horror Shorts banane aur YouTube par upload karne ke liye hai.

## Zaroori baat
- GitHub Actions schedule best-effort hai; exact minute par run guaranteed nahi.
- Workflow 03:30 UTC (9:00 AM IST) aur 13:30 UTC (7:00 PM IST) par scheduled hai.
- Video ka background FFmpeg se procedural dark animated texture hai; stock footage ya copyrighted music nahi.
- Female narration Microsoft Edge TTS ke `hi-IN-SwaraNeural` voice se banti hai. Yeh online TTS service hai; unlimited/free availability guaranteed nahi.
- Groq API free limits/model availability badal sakti hai.
- YouTube OAuth aur API project setup zaroori hai. API projects that have not passed YouTube's audit may have uploads restricted to private.
- Google OAuth consent screen ko Testing mode mein rakhne par YouTube upload scope ka refresh token 7 din mein expire ho sakta hai. Long-running automation ke liye production/publishing and verification requirements check karein.

## GitHub par upload
1. GitHub par New repository banayein: `andheri-raat-automation`.
2. Public repository choose karein (GitHub Actions free minutes ke liye public repo easiest; private repo minutes quota apply hota hai).
3. Is ZIP ke andar ki files repo ke root mein upload karein. `.github/workflows/horror-shorts.yml` ka folder path bilkul same rakhein.
4. Repo → Settings → Secrets and variables → Actions → New repository secret.
5. Yeh 4 secrets add karein:
   - `GROQ_API_KEY`
   - `YOUTUBE_CLIENT_ID`
   - `YOUTUBE_CLIENT_SECRET`
   - `YOUTUBE_REFRESH_TOKEN`
6. Actions tab → workflow → Run workflow se manual test karein.

## Google / YouTube credentials
Google Cloud Console mein project banayein, YouTube Data API v3 enable karein, OAuth consent screen configure karein, aur OAuth Client ID create karein. Scope:
`https://www.googleapis.com/auth/youtube.upload`

OAuth credentials ko secure rakhein. Client ID, client secret, refresh token ya API keys ko chat, comments, public repo, ya screenshots mein share na karein. Sirf GitHub Actions Secrets mein store karein.

Google OAuth app `Testing` status mein ho to refresh token 7 din mein expire ho sakta hai. Production status/verification requirements Google ke current rules par depend karte hain. YouTube Data API ke audit rules ke kaaran uploads private bhi reh sakte hain jab tak project audit pass na kare.

## Manual run
Actions → Andheri Raat - Daily Horror Shorts → Run workflow → morning/evening.

## Important
Pehle private/unlisted test channel ya private upload se verify karein. Public upload ko tabhi enable karein jab title, narration, visual, copyright, and YouTube policy compliance check kar li ho. AI-generated videos par repetitive/low-effort content se monetization reject ho sakta hai. Har story original rakhein aur output review karein.

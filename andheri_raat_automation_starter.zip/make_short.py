import os, re, json, random, subprocess, textwrap, sys
from pathlib import Path
from datetime import datetime, timezone
import requests
import edge_tts
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.auth.transport.requests import Request

OUT = Path("output")
OUT.mkdir(exist_ok=True)

def need(name):
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing GitHub Secret: {name}")
    return value

def make_story():
    key = need("GROQ_API_KEY")
    prompt = """Write one original Hindi horror story for a 45-60 second YouTube Short.
Use natural spoken Hindi in Devanagari, suspenseful and scary but suitable for a general audience.
No gore, graphic violence, real-person allegations, copyrighted characters, or copied urban legends.
Make the first sentence a strong hook; end with a twist. About 90-115 Hindi words.
Return ONLY valid JSON with keys: title (max 70 characters, Hindi), story (story only),
description (short Hindi description), hashtags (array of 4-6 hashtags).
Do not include markdown fences."""
    response = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        json={
            "model": "llama-3.3-70b-versatile",
            "messages": [
                {"role": "system", "content": "You are a creative Hindi horror Shorts writer. Return valid JSON only."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.9,
            "max_tokens": 700
        },
        timeout=90
    )
    response.raise_for_status()
    content = response.json()["choices"][0]["message"]["content"].strip()
    content = re.sub(r"^```(?:json)?|```$", "", content, flags=re.I|re.M).strip()
    data = json.loads(content)
    for k in ("title", "story", "description", "hashtags"):
        if k not in data:
            raise ValueError(f"AI response missing {k}")
    if not isinstance(data["hashtags"], list):
        data["hashtags"] = ["#Horror", "#HindiHorror", "#Shorts", "#AndheriRaat"]
    return data

def make_srt(text, duration, path):
    # Split into short readable caption cards, timed across narration.
    chunks = []
    words = text.split()
    for i in range(0, len(words), 6):
        chunks.append(" ".join(words[i:i+6]))
    if not chunks:
        chunks = [text]
    # Reserve a little tail so captions don't flash after narration.
    usable = max(4.0, duration - 0.25)
    step = usable / len(chunks)
    def stamp(seconds):
        ms = int(seconds * 1000)
        h, ms = divmod(ms, 3600000)
        m, ms = divmod(ms, 60000)
        s, ms = divmod(ms, 1000)
        return f"{h:02}:{m:02}:{s:02},{ms:03}"
    with open(path, "w", encoding="utf-8") as f:
        for i, chunk in enumerate(chunks):
            start = i * step
            end = min(usable, (i+1) * step)
            f.write(f"{i+1}\n{stamp(start)} --> {stamp(end)}\n{chunk}\n\n")

def run(cmd):
    subprocess.run(cmd, check=True)

def make_video(data):
    audio = OUT / "voice.mp3"
    srt = OUT / "captions.srt"
    video = OUT / "short.mp4"
    # Natural-sounding female Hindi voice (Microsoft Edge TTS; online service).
    communicate = edge_tts.Communicate(data["story"], "hi-IN-SwaraNeural", rate="-5%", pitch="-8Hz")
    import asyncio
    asyncio.run(communicate.save(str(audio)))

    probe = subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(audio)
    ], text=True).strip()
    duration = max(35.0, min(60.0, float(probe) + 1.0))
    make_srt(data["story"], duration, srt)

    # Procedural animated dark background: no stock footage or copyrighted music.
    # Captions are burned in; Pexels API is not required.
    srt_path = str(srt.resolve()).replace("\\", "/").replace(":", r"\:")
    vf = (
        "noise=alls=18:allf=t+u,"
        "eq=contrast=1.35:brightness=-0.10:saturation=0.55,"
        "vignette=PI/4,"
        f"subtitles='{srt_path}':force_style='FontName=Noto Sans Devanagari,FontSize=19,"
        "PrimaryColour=&H00FFFFFF,OutlineColour=&H00101010,BorderStyle=1,Outline=2,"
        "Shadow=1,Alignment=2,MarginV=230'"
    )
    run([
        "ffmpeg", "-y",
        "-f", "lavfi", "-i", f"color=c=#09070d:s=1080x1920:r=30:d={duration}",
        "-i", str(audio),
        "-vf", vf,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "25",
        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k",
        "-shortest", "-movflags", "+faststart", str(video)
    ])
    return video

def upload(video, data):
    client_id = need("YOUTUBE_CLIENT_ID")
    client_secret = need("YOUTUBE_CLIENT_SECRET")
    refresh = need("YOUTUBE_REFRESH_TOKEN")
    creds = Credentials(
        token=None,
        refresh_token=refresh,
        token_uri="https://oauth2.googleapis.com/token",
        client_id=client_id,
        client_secret=client_secret,
        scopes=["https://www.googleapis.com/auth/youtube.upload"]
    )
    creds.refresh(Request())
    youtube = build("youtube", "v3", credentials=creds)
    hashtags = " ".join(data["hashtags"][:6])
    description = (data["description"] + "\n\n" + hashtags +
                   "\n\nAise aur Hindi horror Shorts ke liye subscribe karein.\n"
                   "Visual background: procedurally generated. Voice: AI narration.")
    body = {
        "snippet": {
            "title": data["title"][:100],
            "description": description[:4900],
            "tags": ["Hindi horror", "horror story", "scary story", "shorts", "Andheri Raat"],
            "categoryId": "24"
        },
        "status": {
            "privacyStatus": "private",
            "selfDeclaredMadeForKids": False
        }
    }
    request = youtube.videos().insert(
        part="snippet,status",
        body=body,
        media_body=MediaFileUpload(str(video), mimetype="video/mp4", resumable=True)
    )
    result = request.execute()
    print("Uploaded video ID:", result.get("id"))

def main():
    slot = os.getenv("RUN_SLOT", "manual")
    print("Starting Andheri Raat job:", slot, datetime.now(timezone.utc).isoformat())
    data = make_story()
    print("Generated title:", data["title"])
    video = make_video(data)
    upload(video, data)

if __name__ == "__main__":
    main()
